/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package taller;

/**
 *
 * @author utp
 */
public class AUTOMOVILES {
    
    private String marca;
    private String modelo;
    private float precio;

    public AUTOMOVILES(String marca, String modelo, float precio) {
        this.marca = marca;
        this.modelo = modelo;
        this.precio = precio;
    }

    public float getPrecio() {
        return precio;
    }

    public String MostarDatos(){
        
        
        return("la marca del vehiculo es:   Marca: "+marca+" Modelo: "+modelo+" Precio :"+ precio);
    }
    
    
    
}
