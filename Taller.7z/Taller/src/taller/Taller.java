/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package taller;

import javax.swing.JOptionPane;

/**
 *
 * @author utp
 */
public class Taller {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    
    
  
   int n= Integer.parseInt(JOptionPane.showInputDialog("ingrese el numero de autos: "));
   
   
   AUTOMOVILES[] carro = new AUTOMOVILES[20];
   
   for(int i = n;i>0; i--){
    
   String marca = JOptionPane.showInputDialog("marca: ");
   String modelo = JOptionPane.showInputDialog("modelo: ");
   float precio = Float.parseFloat(JOptionPane.showInputDialog("precio: "));
  carro[i] = new AUTOMOVILES(marca,modelo,precio);
       
}
   int cont=0;
   for(int i=n;i>0;i--){
      cont=i;
      float aux=0;
      float aux2 =carro[i].getPrecio();
      
      if (aux>aux2){
          aux=aux2;
          
      }else{
          aux=aux;
          cont=i;
      }
      
       
   }
   
   
        System.out.println("e vehiculo mas barato es:" + carro[cont].MostarDatos());
}  
}
