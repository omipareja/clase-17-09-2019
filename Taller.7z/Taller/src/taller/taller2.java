/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package taller;

import javax.swing.JOptionPane;

/**
 *
 * @author utp
 */
public class taller2 {
      public static void main(String[] args) {
          
    int n=Integer.parseInt(JOptionPane.showInputDialog("cuantos triangulos debe analizar : "));
          
    triangulo[] tri = new triangulo[20];   
    
   for(int i = n;i>0; i--){
    
   double base = Double.parseDouble(JOptionPane.showInputDialog("base: "));
   double lado = Double.parseDouble(JOptionPane.showInputDialog("lado: "));
   
  tri[i] = new triangulo(base,lado);
       
}
   int cont=0;
   for (int i=n;i>0;i--){
       
       double aux=0;
        double aux2=tri[i].Area();
        
       if (aux<aux2){
          aux=aux2;
          
      }else{
          aux=aux;
          cont=i;
      }
      
       
   }
   
   
        System.out.println("El triangulo con mayor superficie es:" + tri[cont].MostarDatos());  
   
   
          
          
      }
}
