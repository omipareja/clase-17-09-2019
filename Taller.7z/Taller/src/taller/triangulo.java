package taller;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author utp
 */
public class triangulo {
    
    private double base;
    private double lado;

    public triangulo(double base, double lado) {
        this.base = base;
        this.lado = lado;
    }

  
   public  double Perimetro(){
      
       return (lado*2+base);
   }
    
    public  double Area(){
      
        return (base*Math.sqrt(((lado*lado)-((base*base)/4))))/2 ;
   }
    
    public String MostarDatos(){
        
        return ("la base es "+ base +"el lado es :"+lado);
    }
     
}
